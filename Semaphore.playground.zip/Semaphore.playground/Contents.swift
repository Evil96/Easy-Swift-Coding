import UIKit

let a = DispatchSemaphore(value: 1)
_ = a.wait(timeout: DispatchTime.distantFuture)

//Here, do something

a.signal()
